#include <stdlib.h>
#include <stdio.h>
#include "pri_queue.h"
/** @file pri_queue.c */
static Node_ptr_t head = NULL;
/**
 * Insert a Node into a priority queue.
 * @param priority
 * @param data
 * @author Awais Irshad 501072162
 */

void PQ_insert(int priority, char * data) {
 //FIX THIS

//    }
    Node_ptr_t ins, temp, prev;
    //need to dynamically allocate memory of node we want to insert (ins)
    ins = (Node_ptr_t)malloc(sizeof(Node_t));
    int ctr;
    //put the parameters into the dynamically allocated memory
    ins-> priority = priority;
    ins->data = data;
    //To determine where the ins node will be
    if(head==NULL){
        //If the linked list does not have any nodes yet, let the one to be inserted become the head
        ins->next=NULL;
        head = ins;
    }
    else if(ins->priority > head->priority){
        //Covers the scenario where the head has a lesser priority than the node to be inserted
        ins->next = head;
        head = ins;
    }
    else{
        /*If the head of the list is already initialized and has greater priority than the node to be
         * inserted, store it in a temporary variable. Now, as long as there are more than two nodes
         * until our tail (NULL) and the current temp's priority is greater than our ins node's, let
         * temp be the next node. If we reach a point at where 2 nodes down from our current temp, we
         * have the tail, we have 3 possible places to insert the ins node; before the temp, after 
         * the temp, or after the node after the temp. We can check where to put the node according
         * to their priorities as done by the block of if-statements after the while loop.         
        */
        temp = head;
        prev = head;
        ctr=0;
        
        while(temp->next->next != NULL && ins->priority < temp->priority){
            ctr+=1;
            if(ctr>0){
                prev = temp;
            }
            temp = temp->next;
        }
        if(ins->priority>temp->priority){
            prev->next = ins;
            ins->next=temp;
        }
        else if(temp->next->priority >= ins->priority){
            temp->next->next = ins;
            ins->next = NULL;
        }
        else{
            ins->next = temp->next;
            temp->next = ins;
        }
    }
}
    
    
/**
 * Delete and return the node with the highest priority.
 * @return The highest priority Node.
 */
Node_ptr_t PQ_delete() {
  //FIX THIS
    //Since the linked list will be in order from greatest to least priority, where greatest is the head, we can 
    //just delete the current head and set the new head to its next node, the next highest priority
    Node_ptr_t temp = head;
    head = head->next;
    return temp;
}

/**
 * Do NOT modify this function.
 * @return A pointer to the head of the list.  (NULL if list is empty.)
 */
Node_ptr_t PQ_get_head() {
    return head;
}

/**
 * Do NOT modify this function.
 * @return the number of items in the queue
 */
int PQ_get_size() {
    int size = 0;
    Node_ptr_t tmp;
    for(tmp = head; tmp != NULL; tmp = tmp->next, size++)
        ;
    return size;
}


